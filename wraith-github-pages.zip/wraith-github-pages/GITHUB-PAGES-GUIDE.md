# WRAITH — GitHub Pages Launch Guide
## Share your app as a live link in under 10 minutes

---

## WHAT YOU'LL GET

A live URL like:
**https://YOUR-USERNAME.github.io/wraith/**

Anyone with the link can open it on their phone like a native app.
Users on Android/iOS can tap "Add to Home Screen" to install it as a PWA.

---

## STEP 1 — Create a free GitHub account

Go to https://github.com and sign up (free).
Pick any username — this becomes part of your app URL.

---

## STEP 2 — Create a new repository

1. Click the **+** icon (top right) → **New repository**
2. Repository name: `wraith`
3. Set to **Public** (required for free GitHub Pages)
4. Check **"Add a README file"**
5. Click **Create repository**

---

## STEP 3 — Upload your files

In your new repository, click **Add file → Upload files**

Upload ALL files from this folder:
- `index.html`
- `manifest.json`
- `sw.js`

Click **Commit changes**.

---

## STEP 4 — Enable GitHub Pages

1. Go to your repository **Settings** (top menu)
2. Scroll down to **Pages** (left sidebar)
3. Under **Source**, select **Deploy from a branch**
4. Branch: **main** / Folder: **/ (root)**
5. Click **Save**

Wait 1–2 minutes, then your site is live at:
**https://YOUR-USERNAME.github.io/wraith/**

---

## STEP 5 — Test on your phone

1. Open the URL on your phone browser
2. On **iPhone**: tap the Share button → "Add to Home Screen"
3. On **Android**: tap the menu (⋮) → "Add to Home Screen" or "Install App"

WRAITH will appear on your home screen with a full-screen dark launch,
just like a native app — no app store needed.

---

## SHARING YOUR APP

Once live, share it any way you want:
- Send the link directly to people
- Post it in paranormal investigation groups
- Create a QR code at https://qr.io (paste your URL, download QR image)
- Add it to your social media bio

---

## UPDATING YOUR APP

Whenever you want to update WRAITH:
1. Go to your GitHub repository
2. Click on `index.html`
3. Click the pencil (edit) icon
4. Paste your updated code
5. Click **Commit changes**

The live site updates automatically within ~1 minute.

---

## CUSTOM DOMAIN (Optional)

If you want a URL like **wraithapp.com** instead of github.io:
1. Buy a domain at Namecheap (~$10/yr) or Google Domains
2. In GitHub Pages settings, enter your custom domain
3. At your domain registrar, add a CNAME record pointing to:
   `YOUR-USERNAME.github.io`

---

## PERMISSIONS ON MOBILE

When users first open WRAITH, their browser will ask for:
- **Microphone** — for Spirit Box, EVP, Reverse Sweep
- **Camera** — for IR Sensor and SLS

They must tap **Allow** for those features to work.

### Browser compatibility:
| Browser | Mic | Camera | Works? |
|---|---|---|---|
| Chrome (Android) | ✅ | ✅ | Full support |
| Safari (iOS 16+) | ✅ | ✅ | Full support |
| Firefox (Android) | ✅ | ✅ | Full support |
| Samsung Internet | ✅ | ✅ | Full support |

---

## TROUBLESHOOTING

**"Site not found" after enabling Pages**
→ Wait 2–3 more minutes, then hard refresh

**Microphone not working**
→ GitHub Pages uses HTTPS, which is required for mic access — this is already handled

**"Add to Home Screen" not appearing on iPhone**
→ Must use Safari browser (not Chrome) on iOS for PWA install

**App looks cut off on iPhone**
→ Already handled — the viewport and apple-mobile-web-app tags are set

---

*WRAITH — Live on the web, free forever with GitHub Pages*
